<?php
// ════════════════════════════════════════════════════════
// FICHIER: database/migrations/
// Exécuter: php artisan migrate
// ════════════════════════════════════════════════════════

// ──────────────────────────────────────────────────────
// 1. create_posts_table.php
// ──────────────────────────────────────────────────────
// php artisan make:migration create_posts_table

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('posts', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->longText('body')->nullable();
            $table->string('image')->nullable();
            $table->string('status')->default('PUBLISHED'); // PUBLISHED | DRAFT
            $table->enum('type', [
                'actualite',
                'evenement_avenir',
                'evenement_passe',
            ])->default('actualite');
            $table->date('event_date')->nullable();
            $table->string('location')->nullable();       // ex: Casablanca
            $table->string('category')->nullable();       // ex: Salon, Formation...
            $table->string('slug')->unique()->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('posts');
    }
};


// ──────────────────────────────────────────────────────
// 2. create_contacts_table.php
// ──────────────────────────────────────────────────────
// php artisan make:migration create_contacts_table

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('contacts', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email');
            $table->text('message');
            $table->enum('status', ['new', 'read', 'replied'])->default('new');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('contacts');
    }
};


// ──────────────────────────────────────────────────────
// 3. create_offres_table.php
// ──────────────────────────────────────────────────────
// php artisan make:migration create_offres_table

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('offres', function (Blueprint $table) {
            $table->id();
            $table->string('full_name');
            $table->string('email');
            $table->string('company_name');
            $table->string('phone')->nullable();
            $table->string('adresse')->nullable();
            $table->enum('type_offre', [
                '600',
                '1000',
                '1500',
                '3000',
                '6000',
                '12000',
                '40000',
            ]);
            $table->enum('status', ['pending', 'confirmed', 'rejected'])->default('pending');
            $table->date('confirmed_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('offres');
    }
};


// ──────────────────────────────────────────────────────
// 4. create_newsletters_table.php
// ──────────────────────────────────────────────────────
// php artisan make:migration create_newsletters_table

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('newsletters', function (Blueprint $table) {
            $table->id();
            $table->string('email_newsletter')->unique();
            $table->boolean('active')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('newsletters');
    }
};
