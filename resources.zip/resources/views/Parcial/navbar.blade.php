
<nav id="navbar">

    {{-- LOGO --}}
    <a href="{{ route('home') }}" class="nav-logo">
        <img src="{{ asset('assets/img/logo_AMPF-white.png') }}"
             alt="AMPF" class="nav-logo-img nav-logo-white">
        <img src="{{ asset('assets/img/logo_AMPF-black.png') }}"
             alt="AMPF" class="nav-logo-img nav-logo-black">
    </a>

    {{-- BURGER (mobile) --}}
    <button class="nav-burger" id="navBurger" aria-label="Menu" aria-expanded="false">
        <span></span><span></span><span></span>
    </button>

    {{-- LINKS --}}
    <ul class="nav-links" id="navLinks">
        <li>
            <a href="{{ route('about') }}"
               class="{{ request()->routeIs('about') ? 'active' : '' }}">
               À propos
            </a>
        </li>

        {{-- Notre Vision --}}
        <li class="nav-dropdown">
            <a href="#" class="nav-dropdown-toggle" aria-expanded="false">
                Notre Vision <i class="fa-solid fa-chevron-down"></i>
            </a>
            <ul class="nav-dropdown-menu">
                <li><a href="{{ route('nos_Valeurs') }}">Nos Valeurs</a></li>
                <li><a href="{{ route('nos_Objectifs') }}">Nos Objectifs</a></li>
                <li><a href="{{ route('nos_strategie') }}">Nos Stratégies</a></li>
            </ul>
        </li>

        {{-- Nos Commissions --}}
        <li>
            <a href="{{ route('commissions') }}"
               class="{{ request()->routeIs('commissions') ? 'active' : '' }}">
                Nos Commissions 
            </a>
        </li>

        {{-- Nos Formules --}}
        <li>
            <a href="{{ route('nos_formule') }}"
               class="{{ request()->routeIs('nos_formule') ? 'active' : '' }}">
               Nos Formules
            </a>
        </li>

        <li>
            <a href="{{ route('media') }}"
               class="{{ request()->routeIs('media') ? 'active' : '' }}">
               Média
            </a>
        </li>

        <li>
            <a href="{{ route('contact') }}"
               class="{{ request()->routeIs('contact') ? 'active' : '' }}">
               Contact
            </a>
        </li>

        <li>
            <div class="nav-lang">
                <button class="lang-btn active" type="button" data-lang="fr">FR</button>
                <button class="lang-btn" type="button" data-lang="en">EN</button>
            </div>
        </li>

        <li>
            <a href="{{ route('offre') }}" class="nav-cta">
                Devenir Membre
            </a>
        </li>
    </ul>
</nav>

{{-- ✅ Script SANS defer, juste avant </body> dans layout.blade.php --}}
{{-- <script src="{{ asset('assets/js/navbar.js') }}"></script> --}}